export default function SnippetLoadingPage() {
  return <div>Loading...</div>;
}
